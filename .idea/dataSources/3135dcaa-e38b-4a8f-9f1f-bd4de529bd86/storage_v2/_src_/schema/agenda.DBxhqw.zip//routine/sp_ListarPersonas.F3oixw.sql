create
    definer = root@localhost procedure sp_ListarPersonas()
begin
		select * from persona;
    end;


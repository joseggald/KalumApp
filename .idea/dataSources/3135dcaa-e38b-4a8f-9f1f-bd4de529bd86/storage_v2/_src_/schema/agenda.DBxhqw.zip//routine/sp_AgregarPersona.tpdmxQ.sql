create
    definer = root@localhost procedure sp_AgregarPersona(IN nombre varchar(30), IN apellido varchar(20), IN edad int)
begin
	start transaction;
	insert into persona(persona.nombre,persona.apellido,persona.edad) values(nombre,apellido,edad);
	commit;
end;

